<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Detail Kendaraan')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <table class="table-auto w-full">
                        <tr>
                            <td class="font-bold py-2 w-1/4">Nomor Polisi</td>
                            <td><?php echo e($vehicle->nomor_polisi); ?></td>
                        </tr>
                        <tr>
                            <td class="font-bold py-2">Merk</td>
                            <td><?php echo e($vehicle->merk); ?></td>
                        </tr>
                        <tr>
                            <td class="font-bold py-2">Model</td>
                            <td><?php echo e($vehicle->model); ?></td>
                        </tr>
                        <tr>
                            <td class="font-bold py-2">Tahun</td>
                            <td><?php echo e($vehicle->tahun); ?></td>
                        </tr>
                        <tr>
                            <td class="font-bold py-2">Warna</td>
                            <td><?php echo e($vehicle->warna); ?></td>
                        </tr>
                        <tr>
                            <td class="font-bold py-2">Jenis</td>
                            <td><?php echo e(ucfirst($vehicle->jenis)); ?></td>
                        </tr>
                    </table>

                    <div class="mt-6">
                        <a href="<?php echo e(route('vehicles.edit', $vehicle)); ?>" class="bg-yellow-500 hover:bg-yellow-700 text-white font-bold py-2 px-4 rounded mr-2">
                            Edit
                        </a>
                        <a href="<?php echo e(route('vehicles.index')); ?>" class="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded">
                            Kembali
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\alba\manajemen-perawatan-kendaraan\resources\views/vehicles/show.blade.php ENDPATH**/ ?>